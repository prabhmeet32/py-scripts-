import sqlite3
import pandas as pd
import os

# 1. First verify the file exists
print("Checking files in directory:", os.listdir())

try:
    # 2. Load CSV with correct parameters
    data = pd.read_csv("Charlottetown.csv",
                       on_bad_lines='skip')  # Fixed parameter name

    # 3. Verify data loaded
    print("\nCSV loaded successfully! First 5 rows:")
    print(data.head())

    # 4. Check for required columns (if needed for database)
    required_columns = ['host_id', 'ip_address', 'mac_address', 'manufacturer']
    if not all(col in data.columns for col in required_columns):
        print("\nError: Missing columns in CSV!")
        print("Required:", required_columns)
        print("Found:", data.columns.tolist())
        exit(1)

except FileNotFoundError:  # Fixed capitalization
    print("\nError: File 'Charlottetown.csv' not found.")
    print("Please verify:")
    print("1. File exists in:", os.getcwd())
    print("2. Exact filename (case matters!)")
    print("3. File extension (.csv only)")
    exit(1)

except Exception as e:
    print(f"\nAn unexpected error occurred: {e}")
    exit(1)

# 5. Database operations (if needed)
try:
    conn = sqlite3.connect("Charlottetown.db")
    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Hosts (
            host_id TEXT PRIMARY KEY,
            ip_address VARCHAR(15),
            mac_address VARCHAR(17),
            manufacturer VARCHAR(255)
    ''')

    # 6. Insert data with duplicate handling
    for row in data.itertuples():
        try:
            cursor.execute(
                '''
                INSERT OR IGNORE INTO Hosts 
                VALUES (?,?,?,?)            ''', (row[1], row[2], row[3], row[4]))
        except sqlite3.IntegrityError:
            print(f"Skipped duplicate host_id: {row.host_id}")

    conn.commit()
    print("\nDatabase updated successfully!")

finally:
    if 'conn' in locals():
        conn.close()