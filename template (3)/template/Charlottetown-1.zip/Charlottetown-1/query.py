import sqlite3

# Connect to database
connection = sqlite3.connect('Charlottetown.db')
crs = connection.cursor()
"""
To run a query:
1. Uncomment ONE query at a time by removing the #
2. Save the file
3. Run in shell with: python query.py
"""

# Query 1: Select all data from Hosts table
query = crs.execute("SELECT * FROM Hosts").fetchall()

# Query 2: Select only ip_address column
# query = crs.execute("SELECT ip_address FROM Hosts").fetchall()

# Query 3: Select Intel manufacturers (FIXED)
# query = crs.execute("SELECT * FROM Hosts WHERE manufacturer LIKE 'Intel%'").fetchall()

# Query 4: Proper INSERT example (FIXED)
#crs.execute("INSERT INTO Hosts (host_id, ip_address, mac_address, manufacturer) VALUES ('13', '10.23.76.199', 'fbdd.1238.2369', 'HP')")
# connection.commit()

# Print results
for row in query:
    print(row)

connection.close()
